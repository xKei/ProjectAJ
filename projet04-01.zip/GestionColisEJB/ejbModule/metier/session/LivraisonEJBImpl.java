package metier.session;

import java.util.List;
import java.util.function.IntBinaryOperator;

import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import metier.entities.Compte_Client;
@Stateless(mappedName="ejb/Livraison")
public class LivraisonEJBImpl implements ILivraisonRemote{

	@PersistenceContext(unitName="GESTION_COLIS1")
	private EntityManager em;

	@Override
	public void addCompteClient(String nom, String prenom, String adresse) {
		Compte_Client compteAjoute = new Compte_Client(nom, prenom, adresse);
		em.persist(compteAjoute);
	}


//	@Override
//	public List<Compte_Client> getAllCompteCli() {
//		Query req =em.createQuery("SELECT c FROM Compte_Client c WHERE 1=1");
//		return req.getResultList();
//	}
//
//	@Override
//	public Compte_Client getCompte(int id_Client) {
//		Compte_Client cp = em.find(Compte_Client.class, id_Client);
//		if(cp==null) throw new RuntimeException("Compte introuvable");
//		return cp;
//	}
	
	

}
