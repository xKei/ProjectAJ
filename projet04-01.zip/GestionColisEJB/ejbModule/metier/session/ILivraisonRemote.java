package metier.session;

import java.util.List;

import javax.ejb.Remote;

import metier.entities.Compte_Client;
@Remote
public interface ILivraisonRemote {
	

//	public List<Compte_Client> getAllCompteCli();
//	public Compte_Client getCompte(int id_Client);
	public void addCompteClient(String nom, String prenom, String adresse);
	
}
