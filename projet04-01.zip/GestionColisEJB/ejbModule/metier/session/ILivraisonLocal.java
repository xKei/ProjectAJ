package metier.session;

import java.util.List;

import javax.ejb.Local;

import metier.entities.Compte_Client;
@Local
public interface ILivraisonLocal {

//	public List<Compte_Client> getAllCompteCli();
//	public Compte_Client getCompte(int id_Client);
	public void addCompteClient(String nom, String prenom, String adresse);
	
}
