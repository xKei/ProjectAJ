package web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import metier.session.ILivraisonRemote;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;




public class FormServlet extends HttpServlet{
		
	private ILivraisonRemote metier;
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
	
		try {
			Context ctx = new InitialContext();
		
			metier = (ILivraisonRemote) ctx.lookup("ejb/Livraison");
			
		} catch (NamingException e) {
			System.out.println("ERREUR INIT");
			e.printStackTrace();
		}
//		req.setAttribute("Livraison", metier.getAllCompteCli());
//		req.getRequestDispatcher("Form.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action= req.getParameter("action");
		if(action.equals("Valider")){
			String nom = req.getParameter("nom");
			String prenom = req.getParameter("prenom");
			String adresse = req.getParameter("adresse");
			metier.addCompteClient(nom,prenom,adresse);
			req.getRequestDispatcher("/Form.jsp").forward(req, resp);
		}
	}
}