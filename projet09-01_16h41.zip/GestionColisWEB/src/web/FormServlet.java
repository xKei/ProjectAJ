package web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import metier.entities.Compte_Client;
import metier.session.ILivraisonRemote;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class FormServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6582818174924107351L;
	private ILivraisonRemote metier;
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();

		try {
			Context ctx = new InitialContext();

			metier = (ILivraisonRemote) ctx.lookup("ejb/Livraison");
			//			getServletContext().getRequestDispatcher("/Form.jsp");
		} catch (NamingException e) {
			System.out.println("ERREUR INIT");
			e.printStackTrace();
		}



	}

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/FormAuth.jsp").forward(req, resp);
		//		req.setAttribute("ListeClient", metier.getAllCompteCli());
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		traitementAuth(req,resp);
		traitementMenu(req,resp);
		traitementInscriptionClient(req, resp);
		traitementDemandeExp(req, resp);
		traitementListeDesClients(req, resp);

	}

	protected void traitementAuth (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		String action= req.getParameter("Action");
		if(action.equals("Connexion")){
			//TO DO TRAITEMENT DE L'AUTHENTIFICATION
			getServletContext().getRequestDispatcher("/FormAuth.jsp").forward(req, resp);
		}
		if(action.equals("Inscription")){
			getServletContext().getRequestDispatcher("/FormInscriptionClient.jsp").forward(req, resp);
		}
		if(action.equals("Retour Menu Principal")){
			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
		}
	}
	protected void traitementMenu (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		String action= req.getParameter("Action");
		//		if(action.equals("MenuInscriptionClient")){
		//			getServletContext().getRequestDispatcher("/FormInscriptionClient.jsp").forward(req, resp);
		//		}
		if(action.equals("MenuDemandeExpeColis")){
			getServletContext().getRequestDispatcher("/FormDmExp.jsp").forward(req, resp);
		}
		else if(action.equals("MenuPrincipal")){
			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
		}
		else if(action.equals("MenuAfficheListClient")){
			System.out.println("TEST MENU AFFICHE LIST CLIENT");
			//			List<Compte_Client> resultat = metier.getAllCompteCli();
			req.setAttribute("listeClient", metier.getAllCompteCli());
			req.getServletContext().getRequestDispatcher("/listclient.jsp").forward(req, resp);


		}
		else if(action.equals("Deconnexion")){
			getServletContext().getRequestDispatcher("/FormAuth.jsp").forward(req, resp);
		}
	}
	protected void traitementInscriptionClient(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException{
		String action= req.getParameter("Action");
		if(action.equals("Valider")){
			String nom = req.getParameter("nom");
			String prenom = req.getParameter("prenom");
			String adresse = req.getParameter("adresse");
			String login = req.getParameter("login");
			String password = req.getParameter("password");
			metier.addCompteClient(nom, prenom, adresse, login, password);
			getServletContext().getRequestDispatcher("/FormInscriptionClient.jsp").forward(req, resp);
		}
		if(action.equals("Retour Menu Principal")){
			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
		}
	}
	protected void traitementListeDesClients (HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException{
		String action= req.getParameter("Action");
		//		req.getRequestDispatcher("/listclient.jsp").forward(req, resp);
		//		req.setAttribute("listeClient", metier.getAllCompteCli());


		if(action.equals("Retour Menu Principal")){
			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
		}
	}
	protected void traitementDemandeExp (HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException{
		String action= req.getParameter("Action");
		if(action.equals("AddColis")){
			String poids = req.getParameter("poids");
			String description = req.getParameter("description");
			System.out.println("Poids : " + poids + "  Description : " 
					+ description + "----------");
			metier.addPanierColis(poids, description);
			getServletContext().getRequestDispatcher("/FormDmExp.jsp").forward(req, resp);
		}
		if(action.equals("Retour Menu Principal")){
			//			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
			this.buttonReturnMenu(action, req, resp);
		}

	}

	public void buttonReturnMenu(String action,HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		if(action.equals("Retour Menu Principal")){
			System.out.println("BUTTONRETURNMENU");
			getServletContext().getRequestDispatcher("/FormAuth.jsp").forward(req, resp);
		}
	}

}