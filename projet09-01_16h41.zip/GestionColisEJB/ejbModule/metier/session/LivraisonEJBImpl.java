package metier.session;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import metier.entities.Compte_Client;
import metier.entities.Panier_Colis;
@Stateless(mappedName="ejb/Livraison")
public class LivraisonEJBImpl implements ILivraisonRemote{

	List<String> listAllClient;

	@PersistenceContext(unitName="GESTION_COLIS1")
	private EntityManager em;

	@Override
	public void addCompteClient(String nom, String prenom, String adresse, String login, String password) {
		Compte_Client compteAjoute = new Compte_Client(nom, prenom, adresse, login, password);
		em.persist(compteAjoute);
	}
	@Override
	public List<Compte_Client> getAllCompteCli() {

		//		Query query =em.createQuery("SELECT c FROM Compte_Client c WHERE 1=1");
		TypedQuery<Compte_Client> query = em.createQuery("SELECT c FROM Compte_Client c",Compte_Client.class);
		//		System.out.println(query.getResultList());
		List<Compte_Client> result;
		//		List<String> listStringResult = new ArrayList<String>();
		result = query.getResultList();
		for(int i=0;i<result.size();i++){
			System.out.println(	" Nom : " + result.get(i).getNom() +
					" | Prenom : " + result.get(i).getPrenom() + 
					" | Adresse : " + result.get(i).getAdresse_Client());
		}
		return result;
	}

	@Override
	public void addPanierColis(String poids, String description) {
		// TODO Auto-generated method stub
		Panier_Colis PanCol = new Panier_Colis(poids, description);
		em.persist(PanCol);
	}



	//	@Override
	//	public List<Compte_Client> getAllCompteCli() {
	//		Query req =em.createQuery("SELECT c FROM Compte_Client c WHERE 1=1");
	//		return req.getResultList();
	//	}
	//
	//	@Override
	//	public Compte_Client getCompte(int id_Client) {
	//		Compte_Client cp = em.find(Compte_Client.class, id_Client);
	//		if(cp==null) throw new RuntimeException("Compte introuvable");
	//		return cp;
	//	}



}
