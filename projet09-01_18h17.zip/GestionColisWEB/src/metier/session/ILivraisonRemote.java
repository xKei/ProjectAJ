package metier.session;

import java.util.List;

import javax.ejb.Remote;

import metier.entities.Compte_Client;
@Remote
public interface ILivraisonRemote {
	
	public abstract List<Compte_Client> getAllCompteCli();
//	public Compte_Client getCompte(int id_Client);
//	public abstract void addCompteClient(String nom, String prenom, String adresse);
	public abstract void addPanierColis(String poids, String description);
	public abstract void addCompteClient(String nom, String prenom, String adresse, String login, String password);

}
