package metier.session;

import java.util.List;

import javax.ejb.Local;

import metier.entities.Compte_Client;
@Local
public interface ILivraisonLocal {

	public abstract List<Compte_Client> getAllCompteCli();
//	public Compte_Client getCompte(int id_Client);
	public abstract void addCompteClient(String nom, String prenom, String adresse);
	public abstract void addPanierColis(String poids, String description);
	
}
