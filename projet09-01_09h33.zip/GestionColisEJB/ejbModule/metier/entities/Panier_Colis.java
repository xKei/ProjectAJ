package metier.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="paniercolis")
public class Panier_Colis implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDCOLIS")
	private int id_Colis;
	@Column(name="POIDS")
	private String poids;
	@Column(name="DESCRIPTION")
	private String description;

	public Panier_Colis() {
		super();
	}

	public Panier_Colis(String poids, String description) {
		super();
		this.poids = poids;
		this.description = description;
	}


	//Getters/Setters
	public String getPoids() {
		return poids;
	}

	public void setPoids(String poids) {
		this.poids = poids;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
