package metier.services;

import java.util.List;

import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import metier.entities.Compte_Client;
import metier.session.ILivraisonLocal;


@WebService
public class LivraisonService {
//	@EJB(beanName="ejb/Livraison")
//	private ILivraisonLocal metier;
//	
//	@WebMethod
//	public List<Compte_Client> listComptes(){
//		return metier.getAllCompteCli();
//	}
//	
////	@WebMethod
////	public Compte_Client getCompte(@WebParam(name="id_client")int id_client){
////		
////		return metier.getCompte(id_client);
////	}
}