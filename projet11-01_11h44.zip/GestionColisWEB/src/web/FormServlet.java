package web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import metier.session.ILivraisonRemote;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.Query;

public class FormServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6582818174924107351L;
	private ILivraisonRemote metier;

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		try {
			Context ctx = new InitialContext();
			metier = (ILivraisonRemote) ctx.lookup("ejb/Livraison");
			//			getServletContext().getRequestDispatcher("/Form.jsp");
		} catch (NamingException e) {
			System.out.println("ERREUR INIT");
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/FormAuth.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		traitementAuth(req,resp);
		traitementLivreur(req, resp);
		traitementMenu(req,resp);
		traitementInscriptionClient(req, resp);
		traitementDemandeExp(req, resp);
		//		traitementListeDesClients(req, resp);

	}

	protected void traitementAuth (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		String action= req.getParameter("Action");
		if(action.equals("Connexion Client")){
			String login = req.getParameter("login");
			String password = req.getParameter("password");
			System.out.println("----- Servlet | Login : " + login + " - Password : " + password);
			if(metier.VerifCoClient(login, password) == true) {
				System.out.println("Authentification r�ussie");
				getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp); 
			} else getServletContext().getRequestDispatcher("/FormAuth.jsp").forward(req, resp);
		}
		if(action.equals("Inscription")){
			getServletContext().getRequestDispatcher("/FormInscriptionClient.jsp").forward(req, resp);
		}
		if(action.equals("Retour Menu Principal")){
			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
		}
		if(action.equals("Connexion Livreur")){
			getServletContext().getRequestDispatcher("/MenuPrincipalLivreur.jsp").forward(req, resp);
		}
	}
	protected void traitementLivreur(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException {
		String action= req.getParameter("Action");
		if(action.equals("Retour Menu Principal")){
			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
		}
	}
	protected void traitementMenu (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		String action= req.getParameter("Action");
		if(action.equals("MenuDemandeExpeColis")){
			this.traitementDemandeExp(req, resp);
		}
		else if(action.equals("MenuPrincipal")){	
			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
		}
		else if(action.equals("MenuAfficheListClient")){
			this.traitementListeDesClients(req, resp);
		}
		else if(action.equals("Deconnexion")){
			getServletContext().getRequestDispatcher("/FormAuth.jsp").forward(req, resp);
		}
	}
	protected void traitementInscriptionClient(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException{
		String action= req.getParameter("Action");
		if(action.equals("Valider")){
			String nom = req.getParameter("nom");
			String prenom = req.getParameter("prenom");
			String adresse = req.getParameter("adresse");
			String login = req.getParameter("login");
			String password = req.getParameter("password");
			metier.addCompteClient(nom, prenom, adresse, login, password);
			getServletContext().getRequestDispatcher("/FormAuth.jsp").forward(req, resp);
		}
		if(action.equals("Retour Menu Principal")){
			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
		}
	}
	protected void traitementListeDesClients (HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException{
		String action= req.getParameter("Action");
		req.setAttribute("listeClient", metier.getAllCompteCli());
		req.getServletContext().getRequestDispatcher("/listclient.jsp").forward(req, resp);

		if(action.equals("Retour Menu Principal")){
			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
		}
	}
	protected void traitementDemandeExp (HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException{
		String action= req.getParameter("Action");
		req.setAttribute("listeColis", metier.getAllPanierColis());
		req.getServletContext().getRequestDispatcher("/FormDmExp.jsp").forward(req, resp);
		//A REFAIRE Checkbox
		Boolean etatCheckBox = (req.getParameter("DemandeUrgente")) != null;
		if(action.equals("Valider Demande d'expedition")){
			String poids = req.getParameter("poids");
			String description = req.getParameter("description");
			String adresseDest = req.getParameter("adresseDest");

			if(etatCheckBox == false){
				metier.addPanierColis(poids, description,adresseDest);
				req.getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
			}
			if(etatCheckBox == true){
				metier.addPanierColisUrgent(poids, description,adresseDest);
				req.getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
			}

			//			this.traitementDemandeExp(req, resp);
		}

		if(action.equals("Retour Menu Principal")){
			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
		}

	}

	public void buttonReturnMenu(String action,HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		if(action.equals("Retour Menu Principal")){
			System.out.println("BUTTONRETURNMENU");
			getServletContext().getRequestDispatcher("/IndexMenu.jsp").forward(req, resp);
		}
	}

}