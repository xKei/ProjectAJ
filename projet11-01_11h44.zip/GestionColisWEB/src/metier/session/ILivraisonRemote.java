package metier.session;

import java.util.List;

import javax.ejb.Remote;

import metier.entities.Compte_Client;
import metier.entities.Panier_Colis;
@Remote
public interface ILivraisonRemote {
	
	public abstract List<Compte_Client> getAllCompteCli();
	public abstract void addPanierColis(String poids, String description, String adresseDest);
	public abstract void addPanierColisUrgent(String poids, String description, String adresseDest);
	public abstract void addCompteClient(String nom, String prenom, String adresse, String login, String password);
	public abstract List<Panier_Colis> getAllPanierColis ();
	public abstract boolean VerifCoClient(String login, String password);
}
