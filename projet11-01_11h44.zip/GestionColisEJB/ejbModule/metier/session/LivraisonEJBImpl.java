package metier.session;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import metier.entities.Compte_Client;
import metier.entities.DistanceVille;
import metier.entities.Panier_Colis;
import metier.entities.Panier_Colis_CLASSIQUE;
import metier.entities.Panier_Colis_URGENT;
@Stateless(mappedName="ejb/Livraison")
public class LivraisonEJBImpl implements ILivraisonRemote{

	private static double prixSansMajo;

	@PersistenceContext(unitName="GESTION_COLIS1")
	private EntityManager em;

	@Override
	public boolean VerifCoClient(String login, String password )
	{
		System.out.println("D�but V�rifCoClient");
		try
		{
			Query req=em.createQuery("FROM Compte_Client c WHERE c.login= '"+login+"'");
			List<Compte_Client> res;
			res=req.getResultList();
			System.out.println("Password BDD : " + res.get(0).getPassword() + " | Password Form : " + password);
			System.out.println("Fin V�rifCoClient");
			return (res.get(0).getPassword().equals(password));
		}catch(Exception e)
		{
			return false ; 
		}
	}

	@Override
	public void addCompteClient(String nom, String prenom, String adresse, String login, String password) {
		Compte_Client compteAjoute = new Compte_Client(nom, prenom, adresse, login, password);
		em.persist(compteAjoute);
	}

	@Override
	public List<Compte_Client> getAllCompteCli() {

		TypedQuery<Compte_Client> query = em.createQuery("SELECT c FROM Compte_Client c",Compte_Client.class);
		List<Compte_Client> result;
		result = query.getResultList();
		//		for(int i=0;i<result.size();i++){
		//			System.out.println(	" Nom : " + result.get(i).getNom() +
		//					" | Prenom : " + result.get(i).getPrenom() + 
		//					" | Adresse : " + result.get(i).getAdresse_Client());
		//		}
		return result;
	}

	@Override
	public void addPanierColis(String poids, String description, String adresseDest) {
		// TODO Auto-generated method stub
		Panier_Colis_CLASSIQUE PanColC = new Panier_Colis_CLASSIQUE(poids, description,adresseDest);
		em.persist(PanColC);
	}
	@Override
	public void addPanierColisUrgent(String poids, String description, String adresseDest) {
		Panier_Colis_URGENT PanColU = new Panier_Colis_URGENT(poids, description, adresseDest);
		em.persist(PanColU);

	}
	public List<Panier_Colis> getAllPanierColis (){
		String SQLRequestGetAllPanierColis="SELECT p FROM Panier_Colis p";
		TypedQuery<Panier_Colis> queryPanierColis = em.createQuery(SQLRequestGetAllPanierColis,Panier_Colis.class);

		List<Panier_Colis> resultListPanierColis;

		resultListPanierColis = queryPanierColis.getResultList();

		for(int i=0;i<resultListPanierColis.size();i++){
			System.out.println(	" id_Colis : " + resultListPanierColis.get(i).getId_Colis() +
					" | Poids : " + resultListPanierColis.get(i).getPoids() + 
					" | Description : " + resultListPanierColis.get(i).getDescription());
		}
		return resultListPanierColis;
	}

	public void calculPrixDistanceSansMajo(){
		String SQLRequestGetAllPanierColis="SELECT p FROM Panier_Colis_CLASSIQUE p";
		TypedQuery<Panier_Colis> queryPanierColis = em.createQuery(SQLRequestGetAllPanierColis,Panier_Colis.class);

		List<Panier_Colis> resultlist = queryPanierColis.getResultList();
		String adresseDestColis = resultlist.get(0).getAdresseDest();
		double poids = Double.parseDouble(resultlist.get(0).getPoids());


		//		String SQLRequestGetDistance = "SELECT d FROM DistanceVille d WHERE d.nomVilleDestination= '"+adresseDestColis+"'";
		//		Query queryDistance = em.createQuery(SQLRequestGetDistance);
		//		List<DistanceVille> resultlistDistance = queryDistance.getResultList();
		double nbDistance = this.getClassDistanceKM(adresseDestColis).getDistanceKM();

		double resultatCalculPrixDistanceSansMajo = poids*nbDistance*0.05;

		for(int i=0;i<resultlist.size();i++){
			resultlist.get(i).setPrix(resultatCalculPrixDistanceSansMajo);
		}
		//		LivraisonEJBImpl.prixSansMajo = resultatCalculPrixDistanceSansMajo;

	}

	public DistanceVille getClassDistanceKM(String adresseDest){
		DistanceVille dv=em.find(DistanceVille.class, adresseDest);
		if (dv==null) throw new RuntimeException("Ville introuvable");
		return dv;
	}

	public static double getPrixSansMajo() {
		return prixSansMajo;
	}

	public void setPrixSansMajo(double prixSansMajo) {
		LivraisonEJBImpl.prixSansMajo = prixSansMajo;
	}


	//	@Override
	//	public List<Compte_Client> getAllCompteCli() {
	//		Query req =em.createQuery("SELECT c FROM Compte_Client c WHERE 1=1");
	//		return req.getResultList();
	//	}
	//
	//	@Override
	//	public Compte_Client getCompte(int id_Client) {
	//		Compte_Client cp = em.find(Compte_Client.class, id_Client);
	//		if(cp==null) throw new RuntimeException("Compte introuvable");
	//		return cp;
	//	}



}
