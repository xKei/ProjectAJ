package metier.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;

import metier.session.LivraisonEJBImpl;

@Entity
//@PrimaryKeyJoinColumn(name="IDCOLIS")
public class Panier_Colis_CLASSIQUE extends Panier_Colis implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public Panier_Colis_CLASSIQUE() {
		// TODO Auto-generated constructor stub
	}

	public Panier_Colis_CLASSIQUE(String poids, String description, String adresseDest) {
		super(poids, description,adresseDest);
		
		// TODO Auto-generated constructor stub
	}



	@Override
	// Poids x 0.05 x Distance
	public void calculerPrix() {
//		this.setPrix(LivraisonEJBImpl.getPrixSansMajo());
	}

}
