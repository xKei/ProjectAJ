package metier.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="DISTANCEVILLE")
public class DistanceVille implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="NOMVILLEDEST")
	private String nomVilleDestination;
	@Column(name="DISTANCEKM")
	private int distanceKM;
	
	public DistanceVille() {
		// TODO Auto-generated constructor stub
	}

	public String getNomVilleDestination() {
		return nomVilleDestination;
	}

	public void setNomVilleDestination(String nomVilleDestination) {
		this.nomVilleDestination = nomVilleDestination;
	}

	public int getDistanceKM() {
		return distanceKM;
	}

	public void setDistanceKM(int distanceKM) {
		this.distanceKM = distanceKM;
	}

}
