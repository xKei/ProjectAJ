package metier.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="COMPTESCLIENT")

public class Compte_Client extends AIndividu implements Serializable{
	private static final long serialVersionUID = 1L;
//	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
//	@Column(name="IDCLI")
//	private int id_Client;
//	@Column(name="NOM")
//	private String nom;
//	@Column(name="PRENOM")
//	private String prenom;
	@Column(name="ADRESSECLI")
	private String adresse_Client;
	@Column(name="PTSFIDELITE")
	private int pointFidelite;
//	@Column(name="LOGIN")
//	private String login;
//	@Column(name="PASSWORD")
//	private String password;
	
	public Compte_Client() {
		super();
		// TODO Auto-generated constructor stub
	}
	
//	public Compte_Client(String nom, String prenom, String adresse_Client) {
//		super();
//		this.nom = nom;
//		this.prenom = prenom;
//		this.adresse_Client = adresse_Client;
//		this.pointFidelite=0;
//	}
	public Compte_Client(String nom, String prenom, String adresse_Client, String login, String password) {
		super(nom,prenom,login,password);
//		this.nom = nom;
//		this.prenom = prenom;
		this.adresse_Client = adresse_Client;
		this.pointFidelite=0;
//		this.login = login;
//		this.password = password;
	}

//	//Getters Setters
//	public int getId_Client() {
//		return id_Client;
//	}
//	public void setId_Client(int id_Client) {
//		this.id_Client = id_Client;
//	}
//	public String getNom() {
//		return nom;
//	}
//	public void setNom(String nom) {
//		this.nom = nom;
//	}
//	public String getPrenom() {
//		return prenom;
//	}
//	public void setPrenom(String prenom) {
//		this.prenom = prenom;
//	}
	public String getAdresse_Client() {
		return adresse_Client;
	}
	public void setAdresse_Client(String adresse_Client) {
		this.adresse_Client = adresse_Client;
	}
	public int getPointFidelite() {
		return pointFidelite;
	}
	public void setPointFidelite(int pointFidelite) {
		this.pointFidelite = pointFidelite;
	}


//	public String getLogin() {
//		return login;
//	}
//
//	public void setLogin(String login) {
//		this.login = login;
//	}
//
//	public String getPassword() {
//		return password;
//	}
//
//	public void setPassword(String password) {
//		this.password = password;
//	}

}
