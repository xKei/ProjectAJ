package metier.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="COMPTESLIVREUR")
public class Compte_Livreur  extends AIndividu implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Compte_Livreur() {
		// TODO Auto-generated constructor stub
	}

	public Compte_Livreur(String nom, String prenom, String login, String password) {
		// TODO Auto-generated constructor stub
		super(nom,prenom,login,password);
	}
	
}
