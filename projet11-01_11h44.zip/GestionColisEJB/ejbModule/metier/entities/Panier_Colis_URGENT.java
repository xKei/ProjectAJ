package metier.entities;

import java.io.Serializable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
@Entity
//@PrimaryKeyJoinColumn(name="IDCOLIS")
public class Panier_Colis_URGENT extends Panier_Colis implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private double majoration;
	public Panier_Colis_URGENT() {
		// TODO Auto-generated constructor stub
	}

	public Panier_Colis_URGENT(String poids, String description, String adresseDest) {
		super(poids, description,adresseDest);
		this.majoration = 0.10;
		// TODO Auto-generated constructor stub
	}

	public double getMajoration() {
		return majoration;
	}

	public void setMajoration(double majoration) {
		this.majoration = majoration;
	}

	@Override
	// Distance x 0.05 x Poids + (Distance x 0.05 x poids * majoration)
	public void calculerPrix() {
		System.out.println("Calcul Prix Commande URGENTE");
	}

}
