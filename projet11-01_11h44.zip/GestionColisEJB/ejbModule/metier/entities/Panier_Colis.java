package metier.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
//@Table(name="paniercolis")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)

public abstract class Panier_Colis implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="IDCOLIS")
	private int id_Colis;
	@Column(name="POIDS")
	private String poids;
	@Column(name="DESCRIPTION")
	private String description;
	@Column(name="ADRESSEDEST")
	private String adresseDest;
	@Column(name="PRIX")
	private double prix;

	public Panier_Colis() {
		super();
	}
	
	public Panier_Colis(String poids, String description, String adresseDest){
		super();
		this.poids = poids;
		this.description = description;
		this.adresseDest=adresseDest;
		this.prix=0;
	}
//	public Panier_Colis(double poids, String description, double prix) {
//		super();
//		this.poids = poids;
//		this.description = description;
//		this.prixTotal=prix;
//	}

	//Method
	
	public abstract void calculerPrix();
	
	//Getters/Setters
	public String getPoids() {
		return poids;
	}

	public void setPoids(String poids) {
		this.poids = poids;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getId_Colis() {
		return id_Colis;
	}

	public void setId_Colis(int id_Colis) {
		this.id_Colis = id_Colis;
	}

	public String getAdresseDest() {
		return adresseDest;
	}

	public void setAdresseDest(String adresseDest) {
		this.adresseDest = adresseDest;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}
}
